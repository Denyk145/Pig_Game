
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

test('index.html exists', () => {
  const filePath = path.join(__dirname, '../index.html');
  expect(fs.existsSync(filePath)).toBe(true);
});

test('script.js exists', () => {
  const filePath = path.join(__dirname, '../script.js');
  expect(fs.existsSync(filePath)).toBe(true);
});
